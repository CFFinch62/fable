\ --- SECTION 4: Your First Word Definition ---

\ Create new words with : name ... ;

: SQUARE DUP * ;

\ Now use your new word:
5 SQUARE .      \ prints 25
6 SQUARE .      \ prints 36
