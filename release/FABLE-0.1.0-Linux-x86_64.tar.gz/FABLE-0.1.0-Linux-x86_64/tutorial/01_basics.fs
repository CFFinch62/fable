\ Lesson 1: The Basics
\ ====================
\ Click "Step" to watch the stack!

\ 1. Pushing numbers
10
20
30

\ 2. Printing (Removing) numbers
.  \ Prints 30
.  \ Prints 20
.  \ Prints 10

\ 3. Stack comments
\ ( This is valid code )
42 ( this stays on the stack )
.
