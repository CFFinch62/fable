\ Lesson 2: Arithmetic
\ ========================
\ Postfix notation: "3 4 +" instead of "3 + 4"

\ Addition
10 5 + .

\ Subtraction
20 8 - .

\ Multiplication
6 7 * .

\ Division
20 4 / .

\ Complex expression: (3 + 4) * 2
3 4 + 2 * .

\ Division with remainder
14 3 /MOD 
. \ Print quotient (4)
. \ Print remainder (2)
